| Cenario | RMSE SLAM (m) | RMSE odometria (m) | Erro final SLAM (m) | Erro final odometria (m) | Erro ang. final SLAM (graus) |
|---|---|---|---|---|---|
| Sequestro | 2.935 | 2.785 | 7.262 | 6.547 | 100.8 |
