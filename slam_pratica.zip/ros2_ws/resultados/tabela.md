| Cenario | RMSE SLAM (m) | RMSE odometria (m) | Erro final SLAM (m) | Erro final odometria (m) | Erro ang. final SLAM (graus) |
|---|---|---|---|---|---|
| Sem ruido (groundtruth) | 0.008 | 0.006 | 0.000 | 0.000 | 0.0 |
| Ruido no Lidar, odometria groundtruth | 0.078 | 0.008 | 0.067 | 0.000 | 0.2 |
| Ruido no Lidar e na odometria | 0.078 | 1.925 | 0.038 | 0.792 | 3.2 |
