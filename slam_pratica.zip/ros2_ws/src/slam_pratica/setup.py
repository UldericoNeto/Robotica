from glob import glob
from setuptools import setup

pkg = 'slam_pratica'

setup(
    name=pkg,
    version='0.1.0',
    packages=[pkg],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + pkg]),
        ('share/' + pkg, ['package.xml']),
        ('share/' + pkg + '/launch', glob('launch/*.py')),
        ('share/' + pkg + '/urdf', glob('urdf/*')),
        ('share/' + pkg + '/worlds', glob('worlds/*')),
        ('share/' + pkg + '/config', glob('config/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='aluno',
    maintainer_email='aluno@todo.todo',
    description='Pratica 05.2 - SLAM',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'odom_ruidosa = slam_pratica.odom_ruidosa:main',
            'explorador = slam_pratica.explorador:main',
            'avaliador = slam_pratica.avaliador:main',
        ],
    },
)
