#!/usr/bin/env python3
"""Exercicio 2.2 - compara os cenarios a partir dos arquivos do avaliador.

Uso: python3 comparar.py [pasta]   (padrao: ~/slam_resultados)
Gera <pasta>/comparacao.png e <pasta>/tabela.md
"""
import csv
import os
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

pasta = os.path.expanduser(sys.argv[1] if len(sys.argv) > 1 else '~/slam_resultados')
CENARIOS = [('sem_ruido', 'Sem ruido (groundtruth)'),
            ('ruido_lidar', 'Ruido no Lidar, odometria groundtruth'),
            ('ruido_total', 'Ruido no Lidar e na odometria')]
SAIDA = 'comparacao'
if len(sys.argv) > 2:  # ex.: comparar.py pasta sequestro  -> sequestro.png
    CENARIOS = [(c, c.replace('_', ' ').capitalize()) for c in sys.argv[2:]]
    SAIDA = '_'.join(sys.argv[2:])
existentes = [(c, t) for c, t in CENARIOS if os.path.exists(os.path.join(pasta, c + '.csv'))]
if not existentes:
    sys.exit(f'nenhum CSV em {pasta}')


def ler_csv(c):
    with open(os.path.join(pasta, c + '.csv')) as f:
        r = csv.reader(f)
        cab = next(r)
        d = np.array([[float(v) for v in linha] for linha in r])
    return {k: d[:, i] for i, k in enumerate(cab)}


def ler_pgm(c):
    caminho = os.path.join(pasta, c + '.pgm')
    if not os.path.exists(caminho):
        return None, None
    with open(caminho, 'rb') as f:
        f.readline()
        w, h = map(int, f.readline().split())
        f.readline()
        img = np.frombuffer(f.read(), dtype=np.uint8).reshape(h, w)
    meta = {}
    with open(os.path.join(pasta, c + '.yaml')) as f:
        for linha in f:
            k, _, v = linha.partition(':')
            meta[k.strip()] = v.strip()
    res = float(meta['resolution'])
    ox, oy = [float(x) for x in meta['origin'].strip('[]').split(',')[:2]]
    return img, (ox, ox + w * res, oy, oy + h * res)


n = len(existentes)
fig, ax = plt.subplots(2, n, figsize=(5.5 * n, 10), squeeze=False)
linhas_tab = ['| Cenario | RMSE SLAM (m) | RMSE odometria (m) | Erro final SLAM (m) | Erro final odometria (m) | Erro ang. final SLAM (graus) |',
              '|---|---|---|---|---|---|']
for j, (c, titulo) in enumerate(existentes):
    d = ler_csv(c)
    img, ext = ler_pgm(c)
    a = ax[0, j]
    if img is not None:
        a.imshow(img, cmap='gray', origin='upper', extent=ext, vmin=0, vmax=255)
    a.plot(d['gt_x'], d['gt_y'], 'g-', lw=2, label='real (Gazebo)')
    a.plot(d['slam_x'], d['slam_y'], 'b--', lw=1.5, label='SLAM (map)')
    a.plot(d['odom_x'], d['odom_y'], color='orange', lw=1.2, label='odometria')
    a.set_title(titulo)
    a.set_aspect('equal')
    a.legend(loc='lower right', fontsize=8)
    a.set_xlabel('x (m)')
    a.set_ylabel('y (m)')

    b = ax[1, j]
    t = d['t'] - d['t'][0]
    b.plot(t, d['erro_slam'], 'b', label='erro SLAM')
    b.plot(t, d['erro_odom'], color='orange', label='erro odometria')
    b.set_xlabel('tempo de simulacao (s)')
    b.set_ylabel('erro de posicao (m)')
    b.grid(alpha=0.3)
    b.legend()
    rm = lambda v: np.sqrt(np.mean(v ** 2))  # noqa: E731
    linhas_tab.append(f'| {titulo} | {rm(d["erro_slam"]):.3f} | {rm(d["erro_odom"]):.3f} | '
                      f'{d["erro_slam"][-1]:.3f} | {d["erro_odom"][-1]:.3f} | '
                      f'{np.degrees(d["erro_ang_slam"][-1]):.1f} |')

fig.tight_layout()
saida = os.path.join(pasta, SAIDA + '.png')
fig.savefig(saida, dpi=110)
with open(os.path.join(pasta, 'tabela.md' if SAIDA == 'comparacao' else SAIDA + '.md'), 'w') as f:
    f.write('\n'.join(linhas_tab) + '\n')
print('\n'.join(linhas_tab))
print('figura:', saida)
