#!/usr/bin/env bash
# Exercicio 3.1 automatizado (equivalente a pausar, arrastar o robo e dar play na interface do Gazebo).
# Use com a simulacao ja rodando e o mapa construido:
#   ros2 launch slam_pratica slam.launch.py cenario:=ruido_total encerrar_ao_fim:=false nome:=sequestro
#   (esperar "Trajetoria concluida")  ->  bash sequestro.sh [x] [y]
set -e
X=${1:-3.8}
Y=${2:--0.5}

echo ">> pausando a simulacao"
gz world -p 1
sleep 2
echo ">> movendo o robo para ($X, $Y) no mundo"
gz model -m robo -x "$X" -y "$Y" -z 0.02 -Y 0
sleep 2
echo ">> retomando a simulacao"
gz world -p 0

sleep 5
echo ">> girando no lugar para o Lidar ver o entorno"
timeout 30 ros2 topic pub -r 10 /cmd_vel geometry_msgs/msg/Twist "{angular: {z: 0.5}}" > /dev/null || true
echo ">> andando um pouco"
timeout 8 ros2 topic pub -r 10 /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.15}}" > /dev/null || true
ros2 topic pub --once /cmd_vel geometry_msgs/msg/Twist "{}" > /dev/null
echo ">> pronto: confira no RViz se a pose do robo voltou ao lugar certo"
