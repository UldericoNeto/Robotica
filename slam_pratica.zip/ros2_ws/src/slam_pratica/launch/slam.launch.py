"""Gazebo + robo com Lidar 2D + odometria (com/sem ruido) + slam_toolbox + RViz.

Exemplos:
  ros2 launch slam_pratica slam.launch.py cenario:=sem_ruido
  ros2 launch slam_pratica slam.launch.py cenario:=ruido_lidar
  ros2 launch slam_pratica slam.launch.py cenario:=ruido_total
  ros2 launch slam_pratica slam.launch.py cenario:=ruido_total auto:=false   (dirigir com teleop)
  ros2 launch slam_pratica slam.launch.py cenario:=ruido_total modo:=localizacao mapa:=$HOME/slam_resultados/mapa_ruido_total

Cenarios (Exercicio 2.2):
  sem_ruido   : Lidar sem ruido, odometria groundtruth (pose do Gazebo)
  ruido_lidar : Lidar com ruido, odometria groundtruth
  ruido_total : Lidar com ruido e odometria das rodas (encoder) com ruido
Qualquer valor pode ser sobrescrito: lidar_ruido:=0.1 ruido_trans:=0.02 ...
"""
import os

import xacro
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, EmitEvent, IncludeLaunchDescription,
                            OpaqueFunction, RegisterEventHandler, SetEnvironmentVariable)
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

PKG = 'slam_pratica'

# lidar_ruido [m], odom_fonte (0 encoder, 1 groundtruth), ruido_trans, ruido_rot, ruido_rot_trans, vies_rot
CENARIOS = {
    'sem_ruido':   dict(lidar_ruido=0.0,  odom_fonte=1, ruido_trans=0.0,  ruido_rot=0.0,
                        ruido_rot_trans=0.0,   vies_rot=0.0),
    'ruido_lidar': dict(lidar_ruido=0.05, odom_fonte=1, ruido_trans=0.0,  ruido_rot=0.0,
                        ruido_rot_trans=0.0,   vies_rot=0.0),
    'ruido_total': dict(lidar_ruido=0.05, odom_fonte=0, ruido_trans=0.01, ruido_rot=0.02,
                        ruido_rot_trans=0.005, vies_rot=0.03),
}
CHAVES = list(CENARIOS['sem_ruido'].keys())


def configurar(context):
    arg = lambda n: LaunchConfiguration(n).perform(context)  # noqa: E731
    share = get_package_share_directory(PKG)
    cenario = arg('cenario')
    if cenario not in CENARIOS:
        raise RuntimeError(f'cenario invalido: {cenario}. Use {list(CENARIOS)}')
    cfg = dict(CENARIOS[cenario])
    for k in CHAVES:  # sobrescritas manuais
        if arg(k) != '':
            cfg[k] = float(arg(k)) if k != 'odom_fonte' else int(arg(k))
    print(f'[slam_pratica] cenario={cenario} {cfg}')

    descricao = xacro.process_file(
        os.path.join(share, 'urdf', 'robo.urdf.xacro'),
        mappings={'lidar_ruido': str(cfg['lidar_ruido']), 'odom_fonte': str(cfg['odom_fonte'])},
    ).toxml()

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')),
        launch_arguments={'world': os.path.join(share, 'worlds', 'sala.world'),
                          'gui': arg('gui'), 'verbose': 'false'}.items(),
    )

    rsp = Node(package='robot_state_publisher', executable='robot_state_publisher',
               parameters=[{'robot_description': descricao, 'use_sim_time': True}])

    spawn = Node(package='gazebo_ros', executable='spawn_entity.py', output='screen',
                 arguments=['-topic', 'robot_description', '-entity', 'robo',
                            '-x', '-4.0', '-y', '-3.0', '-z', '0.02', '-Y', '0.0'])

    odom = Node(package=PKG, executable='odom_ruidosa', output='screen',
                parameters=[{'use_sim_time': True,
                             'ruido_trans': float(cfg['ruido_trans']),
                             'ruido_rot': float(cfg['ruido_rot']),
                             'ruido_rot_trans': float(cfg['ruido_rot_trans']),
                             'vies_rot': float(cfg['vies_rot'])}])

    slam_params = os.path.join(share, 'config', 'slam_toolbox.yaml')
    if arg('modo') == 'localizacao':
        if not arg('mapa'):
            raise RuntimeError('modo:=localizacao exige mapa:=<arquivo serializado, sem extensao>')
        slam = Node(package='slam_toolbox', executable='localization_slam_toolbox_node',
                    name='slam_toolbox', output='screen',
                    parameters=[slam_params, {'use_sim_time': True, 'mode': 'localization',
                                              'map_file_name': os.path.expanduser(arg('mapa')),
                                              'map_start_pose': [0.0, 0.0, 0.0]}])
    else:
        slam = Node(package='slam_toolbox', executable='async_slam_toolbox_node',
                    name='slam_toolbox', output='screen',
                    parameters=[slam_params, {'use_sim_time': True}])

    nome = arg('nome') or (cenario if arg('modo') != 'localizacao' else cenario + '_localizacao')
    avaliador = Node(package=PKG, executable='avaliador', output='screen',
                     parameters=[{'use_sim_time': True, 'cenario': nome, 'saida': arg('saida')}])

    acoes = [gazebo, rsp, spawn, odom, slam, avaliador]

    if arg('rviz') == 'true':
        acoes.append(Node(package='rviz2', executable='rviz2', output='log',
                          arguments=['-d', os.path.join(share, 'config', 'slam.rviz')],
                          parameters=[{'use_sim_time': True}]))

    if arg('auto') == 'true':
        explorador = Node(package=PKG, executable='explorador', output='screen',
                          parameters=[{'use_sim_time': True}])
        acoes.append(explorador)
        if arg('encerrar_ao_fim') == 'true':
            acoes.append(RegisterEventHandler(OnProcessExit(
                target_action=explorador,
                on_exit=[EmitEvent(event=Shutdown(reason='trajetoria concluida'))])))
    return acoes


def generate_launch_description():
    args = [
        DeclareLaunchArgument('cenario', default_value='sem_ruido',
                              description='sem_ruido | ruido_lidar | ruido_total'),
        DeclareLaunchArgument('gui', default_value='true', description='abrir interface do Gazebo'),
        DeclareLaunchArgument('rviz', default_value='true'),
        DeclareLaunchArgument('auto', default_value='true',
                              description='percorrer a trajetoria fixa automaticamente'),
        DeclareLaunchArgument('encerrar_ao_fim', default_value='true',
                              description='desligar tudo quando a trajetoria terminar'),
        DeclareLaunchArgument('modo', default_value='mapeamento', description='mapeamento | localizacao'),
        DeclareLaunchArgument('mapa', default_value='',
                              description='mapa serializado (sem extensao) para modo localizacao'),
        DeclareLaunchArgument('saida', default_value=os.path.expanduser('~/slam_resultados')),
        DeclareLaunchArgument('nome', default_value='',
                              description='nome dos arquivos de resultado (padrao: o cenario)'),
    ] + [DeclareLaunchArgument(k, default_value='') for k in CHAVES]

    return LaunchDescription(args + [
        # evita que o Gazebo tente baixar modelos da internet ao iniciar
        SetEnvironmentVariable('GAZEBO_MODEL_DATABASE_URI', ''),
        OpaqueFunction(function=configurar),
    ])
