# Prática 05.2 — SLAM (ROS2 Humble + Gazebo 11 + slam_toolbox)

Robô diferencial com Lidar 2D em uma sala simples (10 × 8 m, com divisória e obstáculos).
Toda a odometria é **relativa** (dead reckoning): incrementos das rodas integrados pelo nó
`odom_ruidosa`. Não há GPS nem nenhuma fonte absoluta. A pose real do Gazebo (`/ground_truth`)
é usada **somente** para guiar a trajetória automática e para medir o erro. Ela nunca chega ao SLAM.

## Estrutura

| Arquivo | Função |
|---|---|
| `urdf/robo.urdf.xacro` | Robô, Lidar 2D com **ruído gaussiano** (`lidar_ruido`), diff drive e p3d (groundtruth) |
| `worlds/sala.world` | Cenário simples |
| `slam_pratica/odom_ruidosa.py` | Odometria relativa com ruído (`ruido_trans`, `ruido_rot`, `ruido_rot_trans`, `vies_rot`) |
| `config/slam_toolbox.yaml` | Configuração do slam_toolbox (online async, 2D) |
| `slam_pratica/explorador.py` | Percorre sempre a mesma trajetória (comparação justa) |
| `slam_pratica/avaliador.py` | Mede o erro SLAM × real e odometria × real e salva CSV e mapa |
| `scripts/comparar.py` | Gera a figura e a tabela comparando os cenários |
| `launch/slam.launch.py` | Sobe tudo: Gazebo, robô, odometria, slam_toolbox, avaliador e RViz |

## Instalação

```bash
sudo apt install ros-humble-slam-toolbox ros-humble-nav2-map-server
cd ~/ros2_ws && colcon build --symlink-install && source install/setup.bash
```

## Exercício 1.1 — Ruído no Lidar

O ruído está no sensor do Gazebo (`<noise type="gaussian">` em `robo.urdf.xacro`), com o desvio
padrão vindo do argumento `lidar_ruido` (padrão dos cenários com ruído: 0,05 m).

```bash
ros2 launch slam_pratica slam.launch.py cenario:=ruido_lidar lidar_ruido:=0.1
```

## Exercícios 2.1 e 2.2 — slam_toolbox nos três cenários

| `cenario` | Lidar | Odometria |
|---|---|---|
| `sem_ruido` | sem ruído | groundtruth (diff drive com `odometry_source = world`) |
| `ruido_lidar` | σ = 0,05 m | groundtruth |
| `ruido_total` | σ = 0,05 m | encoder das rodas + ruído (σ ≈ 0,1 m/m na translação, ruído angular e viés de 0,03 rad/m) |

```bash
ros2 launch slam_pratica slam.launch.py cenario:=sem_ruido
ros2 launch slam_pratica slam.launch.py cenario:=ruido_lidar
ros2 launch slam_pratica slam.launch.py cenario:=ruido_total
python3 src/slam_pratica/scripts/comparar.py      # gera ~/slam_resultados/comparacao.png e tabela.md
```

Cada execução percorre a trajetória e encerra sozinha, salvando `~/slam_resultados/<cenario>.csv`,
`.pgm` e `.yaml`. Para rodar sem janelas (mais rápido na VM), use `gui:=false rviz:=false`.

## Exercício 3.1 — Robô sequestrado

```bash
ros2 launch slam_pratica slam.launch.py cenario:=ruido_total encerrar_ao_fim:=false
```

1. Espere a trajetória terminar ("Trajetoria concluida" no terminal). O mapa já está construído.
2. No Gazebo, clique em **Pause** (canto inferior esquerdo).
3. Selecione a ferramenta **Translate** (atalho `T`), clique no robô e arraste-o para o outro lado da sala.
4. Clique em **Play** e observe no RViz se a pose (frame `base_footprint` em `map`) volta para o lugar certo.
5. Dirija um pouco para o robô ver partes novas do mapa:
   ```bash
   ros2 run teleop_twist_keyboard teleop_twist_keyboard
   ```
6. Encerre com Ctrl+C. O erro ao longo do tempo fica em `~/slam_resultados/ruido_total.csv`.

**Variante em modo localização** (mapa salvo, sem continuar mapeando):

```bash
# com o mapeamento ainda rodando, salve o grafo de poses:
ros2 service call /slam_toolbox/serialize_map slam_toolbox/srv/SerializePoseGraph "{filename: '$HOME/slam_resultados/mapa_ruido_total'}"
# depois:
ros2 launch slam_pratica slam.launch.py cenario:=ruido_total modo:=localizacao \
    mapa:=$HOME/slam_resultados/mapa_ruido_total auto:=false
```

(Essa variante em modo localização não foi testada; o teste abaixo foi feito em modo mapeamento.)

Versão automática do sequestro (sem interface; usa `gz world -p` e `gz model`):

```bash
ros2 launch slam_pratica slam.launch.py cenario:=ruido_total encerrar_ao_fim:=false nome:=sequestro
# depois de "Trajetoria concluida", em outro terminal:
bash src/slam_pratica/scripts/sequestro.sh 3.8 -0.5
# Ctrl+C no launch e:
python3 src/slam_pratica/scripts/comparar.py ~/slam_resultados sequestro
```

## Resultados obtidos

Trajetória fixa de ~35 m (10 waypoints, termina passando de novo pelo ponto inicial, o que gera
fechamento de laço). Erro = distância entre a pose estimada e a pose real do Gazebo.

| Cenário | RMSE SLAM (m) | RMSE odometria (m) | Erro final SLAM (m) | Erro final odometria (m) |
|---|---|---|---|---|
| Sem ruído (groundtruth) | 0,008 | 0,006 | 0,000 | 0,000 |
| Ruído no Lidar, odometria groundtruth | 0,078 | 0,008 | 0,067 | 0,000 |
| Ruído no Lidar e na odometria | 0,078 | 1,925 | 0,038 | 0,792 |
| Sequestro (ruído total, após o teletransporte) | 2,935 | 2,785 | 7,262 | 6,547 |

Figuras: `comparacao.png` (três cenários) e `sequestro.png`.

**Análise (Exercício 2.2)**

- **Sem ruído:** mapa e trajetória praticamente perfeitos. O erro de ~1 cm é só a diferença de
  instante entre a amostra da TF e a da pose real. As paredes aparecem pontilhadas porque, a 8–10 m,
  os 360 feixes do Lidar ficam mais espaçados que a resolução de 5 cm do mapa.
- **Ruído no Lidar:** as paredes ficam mais grossas e "borradas" (ocupação espalhada por ±σ).
  O scan matching passa a corrigir a odometria, que era perfeita, com base em leituras ruidosas, e
  isso **piora** a pose do SLAM (até ~15 cm, RMSE 7,8 cm). Com odometria perfeita, o SLAM só
  atrapalha.
- **Ruído no Lidar e na odometria:** a odometria sozinha deriva até ~3,5 m (o viés angular gira a
  trajetória). O SLAM mantém o erro em ~0,1 m e o mapa continua consistente: o scan matching corrige
  a deriva continuamente, e o erro final fica em 4 cm. Ao voltar ao ponto inicial, o robô revisita
uma região já mapeada, o que permite fechamento de laço. É aqui que o SLAM
  mostra o seu valor.

**Robô sequestrado (Exercício 3.1)**

Como a odometria é relativa, o robô não "sente" o teletransporte: as rodas não giraram, então a
odometria continua achando que ele está no lugar antigo. O erro do SLAM salta de ~0,2 m para
~8 m e **não se recupera**, mesmo com o robô girando 360° para observar o entorno. Pior: o
slam_toolbox continua mapeando a partir da pose errada e **corrompe o mapa** (contorno da sala
duplicado e girado, com paredes "fantasmas").

O motivo é que o scan matching procura a pose só em uma janela pequena em torno da estimativa
(`correlation_search_space_dimension` = 0,5 m), e o fechamento de laço só procura candidatos até
`loop_search_maximum_distance` = 3 m da pose atual. Um salto de ~8 m fica fora das duas buscas.
Ou seja, o slam_toolbox faz **rastreamento local**, não localização global. Para recuperar seria
preciso relocalização global, por exemplo um filtro de partículas (AMCL) com inicialização global
ou informar a pose manualmente (2D Pose Estimate no RViz em modo localização).
