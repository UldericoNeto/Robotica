"""Odometria relativa (dead reckoning) com ruido configuravel.

Recebe a odometria das rodas do Gazebo (/odom_raw), extrai o deslocamento
incremental entre duas mensagens (no referencial do robo), soma ruido e
integra de novo. Publica /odom e a TF odom -> base_footprint.

Com todos os parametros de ruido em zero, a saida e identica a entrada
(odometria "groundtruth" do cenario sem ruido).

Modelo de ruido (variancia proporcional ao deslocamento, independente da
taxa de publicacao):
    var_trans = ruido_trans * |d_trans|                        [m^2 por m]
    var_rot   = ruido_rot * |d_rot| + ruido_rot_trans * |d_trans|
    d_rot    += vies_rot * d_trans                              [rad por m]
"""
import math

import numpy as np
import rclpy
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from tf2_ros import TransformBroadcaster


def yaw_de(q):
    return math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))


def ang_norm(a):
    return math.atan2(math.sin(a), math.cos(a))


class OdomRuidosa(Node):
    def __init__(self):
        super().__init__('odom_ruidosa')
        self.declare_parameter('ruido_trans', 0.0)
        self.declare_parameter('ruido_rot', 0.0)
        self.declare_parameter('ruido_rot_trans', 0.0)
        self.declare_parameter('vies_rot', 0.0)
        self.declare_parameter('semente', 42)
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_footprint')

        p = lambda n: self.get_parameter(n).value  # noqa: E731
        self.k_t, self.k_r, self.k_rt, self.vies = p('ruido_trans'), p('ruido_rot'), p('ruido_rot_trans'), p('vies_rot')
        self.odom_frame, self.base_frame = p('odom_frame'), p('base_frame')
        self.rng = np.random.default_rng(p('semente'))

        self.anterior = None          # (x, y, th) da odometria bruta
        self.x = self.y = self.th = 0.0

        self.pub = self.create_publisher(Odometry, 'odom', 10)
        self.tf = TransformBroadcaster(self)
        self.create_subscription(Odometry, 'odom_raw', self.cb, 20)
        self.get_logger().info(
            f'ruido_trans={self.k_t} ruido_rot={self.k_r} ruido_rot_trans={self.k_rt} vies_rot={self.vies}')

    def cb(self, msg):
        pose = msg.pose.pose
        atual = (pose.position.x, pose.position.y, yaw_de(pose.orientation))
        if self.anterior is None:
            self.anterior = atual
        x0, y0, t0 = self.anterior
        self.anterior = atual

        # deslocamento no referencial do robo
        dxw, dyw = atual[0] - x0, atual[1] - y0
        dx = math.cos(t0) * dxw + math.sin(t0) * dyw
        dy = -math.sin(t0) * dxw + math.cos(t0) * dyw
        dth = ang_norm(atual[2] - t0)
        d_trans = math.hypot(dx, dy)

        if d_trans > 1e-6 or abs(dth) > 1e-6:
            s_t = math.sqrt(self.k_t * d_trans)
            s_r = math.sqrt(self.k_r * abs(dth) + self.k_rt * d_trans)
            if s_t > 0 and d_trans > 1e-6:
                f = 1.0 + self.rng.normal(0.0, s_t) / d_trans
                dx, dy = dx * f, dy * f
            dth += self.vies * d_trans * (1 if dx >= 0 else -1)
            if s_r > 0:
                dth += self.rng.normal(0.0, s_r)

        # integra no referencial odom
        self.x += math.cos(self.th) * dx - math.sin(self.th) * dy
        self.y += math.sin(self.th) * dx + math.cos(self.th) * dy
        self.th = ang_norm(self.th + dth)

        qz, qw = math.sin(self.th / 2.0), math.cos(self.th / 2.0)
        out = Odometry()
        out.header.stamp = msg.header.stamp
        out.header.frame_id = self.odom_frame
        out.child_frame_id = self.base_frame
        out.pose.pose.position.x = self.x
        out.pose.pose.position.y = self.y
        out.pose.pose.orientation.z = qz
        out.pose.pose.orientation.w = qw
        out.twist = msg.twist
        self.pub.publish(out)

        t = TransformStamped()
        t.header = out.header
        t.child_frame_id = self.base_frame
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw
        self.tf.sendTransform(t)


def main():
    rclpy.init()
    no = OdomRuidosa()
    try:
        rclpy.spin(no)
    except KeyboardInterrupt:
        pass
    finally:
        no.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
