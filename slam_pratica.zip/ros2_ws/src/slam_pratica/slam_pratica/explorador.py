"""Percorre uma trajetoria fixa pela sala (mesma em todos os cenarios),
para que a comparacao do SLAM seja justa. Usa a pose do Gazebo apenas para
GUIAR o robo; o SLAM nunca recebe essa informacao.

Ao terminar, para o robo, espera alguns segundos e encerra (o launch
desliga tudo e o avaliador salva os resultados).
"""
import math

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node

# (x, y) no referencial do mundo; o robo nasce em (-4, -3)
WAYPOINTS = [(-4.0, 3.0), (4.0, 3.0), (4.0, -3.2), (1.0, -3.2), (1.0, 0.0),
             (-1.0, 0.0), (-1.0, -3.2), (-3.2, -3.2), (-4.0, -3.0), (-4.0, 0.0)]


def yaw_de(q):
    return math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))


class Explorador(Node):
    def __init__(self):
        super().__init__('explorador')
        self.declare_parameter('vel_lin', 0.35)
        self.declare_parameter('vel_ang', 0.8)
        self.declare_parameter('espera_final', 8.0)
        self.v = self.get_parameter('vel_lin').value
        self.w = self.get_parameter('vel_ang').value
        self.espera = self.get_parameter('espera_final').value
        self.i = 0
        self.pose = None
        self.fim = None
        self.pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.create_subscription(Odometry, 'ground_truth', self.cb, 10)
        self.create_timer(0.05, self.passo)

    def cb(self, msg):
        p = msg.pose.pose
        self.pose = (p.position.x, p.position.y, yaw_de(p.orientation))

    def passo(self):
        if self.pose is None:
            return
        cmd = Twist()
        if self.i >= len(WAYPOINTS):
            agora = self.get_clock().now().nanoseconds * 1e-9
            if self.fim is None:
                self.fim = agora
                self.get_logger().info('Trajetoria concluida.')
            self.pub.publish(cmd)
            if agora - self.fim > self.espera:
                raise SystemExit
            return
        x, y, th = self.pose
        gx, gy = WAYPOINTS[self.i]
        dist = math.hypot(gx - x, gy - y)
        if dist < 0.12:
            self.get_logger().info(f'waypoint {self.i + 1}/{len(WAYPOINTS)} ({gx}, {gy})')
            self.i += 1
            self.pub.publish(cmd)
            return
        erro = math.atan2(gy - y, gx - x) - th
        erro = math.atan2(math.sin(erro), math.cos(erro))
        if abs(erro) > 0.35:  # gira no lugar
            cmd.angular.z = max(-self.w, min(self.w, 2.0 * erro))
        else:
            cmd.linear.x = min(self.v, 0.6 * dist + 0.05)
            cmd.angular.z = max(-self.w, min(self.w, 2.0 * erro))
        self.pub.publish(cmd)


def main():
    rclpy.init()
    no = Explorador()
    try:
        rclpy.spin(no)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        no.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
