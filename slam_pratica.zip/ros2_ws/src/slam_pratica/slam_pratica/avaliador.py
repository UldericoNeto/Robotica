"""Mede o erro de localizacao do SLAM e da odometria em relacao a pose real.

A cada 0.5 s (tempo de simulacao) registra:
  - pose real do Gazebo (/ground_truth), expressa no referencial inicial do robo
    (que coincide com os referenciais map e odom no instante zero);
  - pose estimada pelo SLAM (TF map -> base_footprint);
  - pose da odometria (TF odom -> base_footprint).
Ao encerrar (Ctrl+C ou fim do launch) grava <saida>/<cenario>.csv e o ultimo
mapa recebido em <saida>/<cenario>.pgm/.yaml, e imprime o RMSE.
"""
import csv
import math
import os

import numpy as np
import rclpy
from nav_msgs.msg import OccupancyGrid, Odometry
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from tf2_ros import Buffer, TransformListener


def yaw_q(q):
    return math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))


def ang_norm(a):
    return math.atan2(math.sin(a), math.cos(a))


class Avaliador(Node):
    def __init__(self):
        super().__init__('avaliador')
        self.declare_parameter('cenario', 'teste')
        self.declare_parameter('saida', os.path.expanduser('~/slam_resultados'))
        self.cenario = self.get_parameter('cenario').value
        self.saida = os.path.expanduser(self.get_parameter('saida').value)
        os.makedirs(self.saida, exist_ok=True)

        self.gt0 = None
        self.gt = None
        self.mapa = None
        self.linhas = []
        self.buf = Buffer()
        self.tfl = TransformListener(self.buf, self)
        self.create_subscription(Odometry, 'ground_truth', self.cb_gt, 10)
        qos_mapa = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                              durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(OccupancyGrid, 'map', self.cb_mapa, qos_mapa)
        self.create_timer(0.5, self.registrar)

    def cb_gt(self, msg):
        p = msg.pose.pose
        x, y, th = p.position.x, p.position.y, yaw_q(p.orientation)
        if self.gt0 is None:
            self.gt0 = (x, y, th)
        x0, y0, t0 = self.gt0
        dx, dy = x - x0, y - y0
        self.gt = (math.cos(t0) * dx + math.sin(t0) * dy,
                   -math.sin(t0) * dx + math.cos(t0) * dy,
                   ang_norm(th - t0))

    def cb_mapa(self, msg):
        self.mapa = msg

    def pose_tf(self, origem):
        try:
            t = self.buf.lookup_transform(origem, 'base_footprint', Time())
        except Exception:  # noqa: BLE001
            return None
        tr = t.transform
        return (tr.translation.x, tr.translation.y, yaw_q(tr.rotation))

    def registrar(self):
        if self.gt is None:
            return
        slam = self.pose_tf('map')
        odom = self.pose_tf('odom')
        if slam is None or odom is None:
            return
        t = self.get_clock().now().nanoseconds * 1e-9
        e_slam = math.hypot(slam[0] - self.gt[0], slam[1] - self.gt[1])
        e_odom = math.hypot(odom[0] - self.gt[0], odom[1] - self.gt[1])
        self.linhas.append([t, *self.gt, *slam, *odom, e_slam, e_odom,
                            abs(ang_norm(slam[2] - self.gt[2])), abs(ang_norm(odom[2] - self.gt[2]))])

    def salvar(self):
        base = os.path.join(self.saida, self.cenario)
        with open(base + '.csv', 'w', newline='') as f:
            w = csv.writer(f)
            w.writerow(['t', 'gt_x', 'gt_y', 'gt_th', 'slam_x', 'slam_y', 'slam_th',
                        'odom_x', 'odom_y', 'odom_th', 'erro_slam', 'erro_odom',
                        'erro_ang_slam', 'erro_ang_odom'])
            w.writerows(self.linhas)
        if self.mapa is not None:
            m = self.mapa
            d = np.array(m.data, dtype=np.int16).reshape(m.info.height, m.info.width)
            img = np.full(d.shape, 205, dtype=np.uint8)
            img[d == 0] = 254
            img[d > 50] = 0
            img = np.flipud(img)
            with open(base + '.pgm', 'wb') as f:
                f.write(f'P5\n{m.info.width} {m.info.height}\n255\n'.encode())
                f.write(img.tobytes())
            o = m.info.origin.position
            with open(base + '.yaml', 'w') as f:
                f.write(f'image: {self.cenario}.pgm\nresolution: {m.info.resolution}\n'
                        f'origin: [{o.x}, {o.y}, 0.0]\nnegate: 0\noccupied_thresh: 0.65\n'
                        f'free_thresh: 0.25\nmode: trinary\n')
        if self.linhas:
            a = np.array(self.linhas)
            print(f'[{self.cenario}] amostras={len(a)}  '
                  f'RMSE SLAM={np.sqrt(np.mean(a[:, 10] ** 2)):.3f} m  '
                  f'RMSE odometria={np.sqrt(np.mean(a[:, 11] ** 2)):.3f} m  '
                  f'erro final SLAM={a[-1, 10]:.3f} m  odometria={a[-1, 11]:.3f} m', flush=True)
        print(f'[{self.cenario}] resultados salvos em {base}.*', flush=True)


def main():
    rclpy.init()
    no = Avaliador()
    try:
        rclpy.spin(no)
    except KeyboardInterrupt:
        pass
    finally:
        no.salvar()
        no.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
